<?php defined('BASEPATH') OR exit('No direct script access allowed');
$config = [
'protocol' => 'smtp',
'smtp_host' => 'smtp.mailtrap.io',
'smtp_port' => 465,
'smtp_user' => 'info@shriganpatipackers.com',
'smtp_pass' => 'King@2696',
'crlf' => "\r\n",
'newline' => "\r\n"
];
