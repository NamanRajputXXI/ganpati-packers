<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mailer extends CI_Controller {
	function __construct() {
        parent::__construct();
    }
	public function send() {
		$this->load->config('email');
		$this->load->library('email');
	
		$from = 'no-reply@myapp.com';
		$to = $this->input->post('to');
		$to= "info@shriganpatipackers.com";
		$this->email->from($from);
		$this->email->to($to);
		$this->email->subject('New email');
		$this->email->message('New email received!');
	
		if ($this->email->send()) {
			echo json_encode([ "status" => "OK", "res_code" => "200", "message" => "SENT"]);
			echo 'Sent with success!';
		} else {
			$error = show_error($this->email->print_debugger());
			echo json_encode([ "status" => "ERR", "res_code" => "500", "message" => $error ]);
		}
	}
}
